<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class RunToSize extends Model
{
    public $table = 'runtosize';
    public $timestamps = false;
    public $primaryKey = 'runToSizeId';
}
