<?php
define('ONE', '1');
define('TWO', '2');
define('SIZE',array(
    "m" => "m",
    "l" => "l",
    "s" => "s",
    "xl" => "xl",
));

define('STATE',array("11", "1", "2", "3"));


//to get type from history
define('LISTTYPE',array("ProductList", "OfferList"));

define('ProductIdType',array("SHOP_SKU"));




define('SizeCategory',
    array("Womenswear clothing / lingerie",
        "Womenswear shoes",
        "Womenswear jewellery/watches/sunglasses",
        "Womenswear gloves",
        "Womenswear hats",
        "Womenswear belts",
        "Menswear clothing",
        "Menswear shoes",
        "Menswear gloves",
        "Menswear hats",
        "Menswear jewellery/ties/watches",
        "Menswear belts",
        "Technology accessories",
        "Girlswear clothing",
        "Girlswear shoes",
        "Girlswear accessories",
        "Boyswear clothing",
        "Boyswear shoes",
        "Boyswear accessories",
        "Babywear clothing",
        "Babywear shoes",
        "Babywear accessories"
        )
);

define('Status',array("New","Downloaded"));


define('SettingListDropdown',array("season","category","color","size","care","runtosize"));


